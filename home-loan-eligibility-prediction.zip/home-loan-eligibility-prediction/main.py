from flask import Blueprint, render_template, Flask, request
from flask_login import login_required, current_user
from __init__ import create_app, db
import pickle

main = Blueprint('main', __name__)
model = pickle.load(open('model.pkl', 'rb')) # loading the trained model

@main.route('/') # home page that return 'index'
def index():
    return render_template('index.html')

@main.route('/profile') # profile page to enter the user details and then check the eligibility
@login_required
def profile():
    return render_template('profile.html', name=current_user.name)

@main.route('/predict',methods=['POST']) # This function will take the user input and run thru our prediction app to check the eligibility
def predict():
    if request.method == 'POST':
        print ('line 21')
        gender=int(request.form['gender'])
        married=int(request.form['married'])
        dependents=float(request.form['dependents'])
        education=int(request.form['education'])
        self_employed=int(request.form['self_employed'])
        applicantincome=request.form['applicantincome']
        coapplicantincome=request.form['coapplicantincome']
        loanamount=request.form['loanamount']
        loan_amount_term=request.form['loan_amount_term']
        credit_history=request.form['credit_history']
        property_area=request.form['property_area']

    prediction = model.predict([[gender,married,dependents,education,self_employed,applicantincome,coapplicantincome,loanamount,loan_amount_term,credit_history,property_area]])

    output=round(prediction[0],2)
    
    if (output >= 0.5):
        textOut = "Congratulations "+current_user.name+" !! You are eligible for a loan..."
    else:
        textOut = "We Regret to inform you  "+current_user.name+", that you are not eligible for a loan..."
    # rendering the predicted result
    return render_template("predict.html", prediction_text= "{}".format(textOut))

app = create_app() # we initialize our flask app using the __init__.py function
if __name__ == '__main__':
   # db.create_all(create_app())
    app.run(debug=True) # run the flask app on debug mode